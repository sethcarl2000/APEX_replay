
#include <APEX/VDC/HitGroup.h> 
#include <stdexcept> 
#include <TString.h> 
#include <APEX/utils.h> 

namespace APEX
{
namespace VDC
{


void HitGroup::AddHit( double wire, double rawTime ) 
{   
  fHits.push_back(Hit(fPlane,wire,rawTime)); 
}
double HitGroup::WirePos( unsigned int h ) const 
{   
  if (h>=Nhits()) {
    throw std::logic_error(Form("<%s::%s> hit index %u out-of-range; max is %u", 
        kNamespaceName, __func__, 
        Nhits()-1, h
    ));
    return utils::kNaN; 
  }
  return fHits[h].wPos();
}
int    HitGroup::WireNum( unsigned int h ) const 
{ 
  if (h>=Nhits()) {
    throw std::logic_error(Form("<%s::%s> hit index %u out-of-range; max is %u", 
        kNamespaceName, __func__, 
        Nhits()-1, h
    ));
    return -1; 
  }
  
  return fHits[h].wNum(); 
}
double HitGroup::Time( unsigned int h )    const 
{ 
  if (h>=Nhits()) {
    throw std::logic_error(Form("<%s::%s> hit index %u out-of-range; max is %u", 
        kNamespaceName, __func__, 
        Nhits()-1, h
    ));
    return utils::kNaN; 
  }
  
  return fHits[h].Time(); 
}
int    HitGroup::FirstWire() const { return fHits.front().wNum(); }
double HitGroup::LoEdge()    const { return fHits.back().wPos(); }
double HitGroup::HiEdge()    const { return fHits.front().wPos(); }

};
}